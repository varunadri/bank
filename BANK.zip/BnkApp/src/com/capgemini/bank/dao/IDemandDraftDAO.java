package com.capgemini.bank.dao;

import com.capgemini.bank.bean.DemandDraftBean;
import com.capgemini.bank.exception.BankException;

public interface IDemandDraftDAO {

	public int addDD(DemandDraftBean dd) throws BankException;
	public DemandDraftBean getDemandDraft(int tranId) throws BankException;
	
}
