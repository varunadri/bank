package com.capgemini.bank.bean;

public class DemandDraftBean {

	private int tranId;
	private String name;
	private String mobNo;
	private String inFavour;
	private String ddAmount;
	private String remarks;
	public int getTranId() {
		return tranId;
	}
	public void setTranId(int tranId) {
		this.tranId = tranId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public String getInFavour() {
		return inFavour;
	}
	public void setInFavour(String inFavour) {
		this.inFavour = inFavour;
	}
	public String getDdAmount() {
		return ddAmount;
	}
	public void setDdAmount(String ddAmount) {
		this.ddAmount = ddAmount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
