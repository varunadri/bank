package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraftBean;
import com.capgemini.bank.exception.BankException;

public interface IDemandDraftService {

	public int addDD(DemandDraftBean dd) throws BankException;
	public DemandDraftBean getDemandDraft(int tranId) throws BankException;
	public boolean isValidDemandDraft(DemandDraftBean dd) throws BankException;

}
