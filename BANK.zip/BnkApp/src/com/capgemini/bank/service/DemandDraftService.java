package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraftBean;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.BankException;

public class DemandDraftService implements IDemandDraftService {

	IDemandDraftDAO ddao = new DemandDraftDAO();

	@Override
	public int addDD(DemandDraftBean dd) throws BankException {
		return ddao.addDD(dd);
	}

	@Override
	public DemandDraftBean getDemandDraft(int tranId) throws BankException {
		return ddao.getDemandDraft(tranId);
	}

	@Override
	public boolean isValidDemandDraft(DemandDraftBean dd) throws BankException {
		 if(!dd.getMobNo().matches("[0-9]{10}")){
	 	    	throw new BankException("Contact numner must be of 10 Digits..", null);
	 	    }
	 	    
	 	    if(dd.getName()==null||dd.getDdAmount()==null||dd.getInFavour()==null){
	 	    	throw new BankException(" Name,DD Amount , In Favour Of must be filled.", null);
	 	    }
	 	   
		return true;
	}

	
}
